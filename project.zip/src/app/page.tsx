"use client"

import Homepage from "@/components/homepage"

export default function Page() {
  return <Homepage />
}
